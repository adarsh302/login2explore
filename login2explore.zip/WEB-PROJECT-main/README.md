Title of the Project: WEB-PROJECT

Description: This is a Web-Project using JSON DB in Netbeans. 

Benefits of using JsonPowerDB: 
     1.Simplest way to retrieve data in a JSON format.
    2.Schema-free, Simple to use, Nimble and In-Memory database.
    3.It is built on top of one of the fastest and real-time data indexing engine - PowerIndeX.
    4.It is low level (raw) form of data and is also human readable.
 
 Release History: Today only (6/15/2022)
